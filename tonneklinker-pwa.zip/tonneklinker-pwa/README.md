
# Tonneklinker PWA
Installable PWA for rack scanning + wine search.

**Deploy (GitHub Pages)**
1) Create repo `tonneklinker`, upload these files.  
2) Settings → Pages → Deploy from branch (`main` / root).  
3) Visit `https://<username>.github.io/tonneklinker/`.

**Configure Airtable (desktop)**
Open `/index.html` → Settings → paste **Base ID** & **Personal Access Token**.  
Tables: `Wines`, `Inventory`, `Locations`.
